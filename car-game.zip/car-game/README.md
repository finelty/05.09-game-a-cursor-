﻿# Car Game

A minimal canvas car dodging game. Steer left/right to avoid incoming traffic, score by surviving longer.

## Run

Just open `index.html` in a modern browser (Chrome, Edge, Firefox). No build step.

- If double-click does not work, right-click `index.html` → Open with → your browser.

## Controls

- Left/Right arrows or A/D: steer lanes
- P: pause/resume
- Enter: start/restart

## Files

- `index.html`: page and canvas
- `style.css`: minimal UI styling
- `main.js`: game loop, input, collision, scoring
