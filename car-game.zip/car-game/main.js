﻿(function() {
  "use strict";

  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d");

  const scoreEl = document.getElementById("score");
  const bestEl = document.getElementById("best");
  const overlay = document.getElementById("overlay");
  const startBtn = document.getElementById("startBtn");
  const pauseBtn = document.getElementById("pauseBtn");

  const WIDTH = canvas.width;
  const HEIGHT = canvas.height;
  const ROAD_PADDING = 40;
  const LANE_COUNT = 3;
  const LANE_WIDTH = (WIDTH - ROAD_PADDING * 2) / LANE_COUNT;
  const LANE_CENTER_X = (lane) => ROAD_PADDING + lane * LANE_WIDTH + LANE_WIDTH / 2;

  const PLAYER_WIDTH = 42;
  const PLAYER_HEIGHT = 70;
  const ENEMY_WIDTH = 42;
  const ENEMY_HEIGHT = 70;

  const STATE = {
    Running: "running",
    Paused: "paused",
    GameOver: "gameover",
    Idle: "idle",
  };

  let gameState = STATE.Idle;
  let score = 0;
  let best = Number(localStorage.getItem("car_game_best") || "0");
  bestEl.textContent = String(best);

  const player = {
    laneIndex: 1,
    x: LANE_CENTER_X(1) - PLAYER_WIDTH / 2,
    y: HEIGHT - PLAYER_HEIGHT - 20,
    speed: 300,
    targetLane: 1,
    laneChangeSpeed: 10,
  };

  /** @type {{x:number,y:number,lane:number,speed:number}[]} */
  let enemies = [];

  const input = { left: false, right: false };

  function resetGame() {
    score = 0;
    enemies = [];
    player.laneIndex = 1;
    player.targetLane = 1;
    player.x = LANE_CENTER_X(1) - PLAYER_WIDTH / 2;
    player.y = HEIGHT - PLAYER_HEIGHT - 20;
  }

  function spawnEnemy() {
    const lane = Math.floor(Math.random() * LANE_COUNT);
    const speed = 180 + Math.random() * 160 + Math.min(score, 600) * 0.15;
    enemies.push({
      lane,
      x: LANE_CENTER_X(lane) - ENEMY_WIDTH / 2,
      y: -ENEMY_HEIGHT - 20,
      speed,
    });
  }

  let spawnTimer = 0;
  const SPAWN_INTERVAL_BASE = 900; // ms
  const SPAWN_INTERVAL_MIN = 350;

  function updateSpawn(dtMs) {
    if (gameState !== STATE.Running) return;
    spawnTimer += dtMs;
    const difficulty = Math.min(score / 100, 1);
    const interval = SPAWN_INTERVAL_BASE - difficulty * (SPAWN_INTERVAL_BASE - SPAWN_INTERVAL_MIN);
    if (spawnTimer >= interval) {
      spawnTimer = 0;
      spawnEnemy();
    }
  }

  function updatePlayer(dt) {
    const desiredX = LANE_CENTER_X(player.targetLane) - PLAYER_WIDTH / 2;
    const dx = desiredX - player.x;
    if (Math.abs(dx) > 1) {
      player.x += dx * Math.min(1, player.laneChangeSpeed * dt);
    } else {
      player.x = desiredX;
      player.laneIndex = player.targetLane;
    }
  }

  function updateEnemies(dt) {
    for (let i = enemies.length - 1; i >= 0; i--) {
      enemies[i].y += enemies[i].speed * dt;
      if (enemies[i].y > HEIGHT + 60) {
        enemies.splice(i, 1);
        score += 1;
        scoreEl.textContent = String(score);
      }
    }
  }

  function rectsOverlap(ax, ay, aw, ah, bx, by, bw, bh) {
    return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
  }

  function checkCollisions() {
    const px = player.x;
    const py = player.y;
    for (let i = 0; i < enemies.length; i++) {
      const e = enemies[i];
      if (rectsOverlap(px, py, PLAYER_WIDTH, PLAYER_HEIGHT, e.x, e.y, ENEMY_WIDTH, ENEMY_HEIGHT)) {
        endGame();
        return;
      }
    }
  }

  function drawRoad() {
    ctx.fillStyle = "#0b0f18";
    ctx.fillRect(0, 0, WIDTH, HEIGHT);

    // asphalt
    ctx.fillStyle = "#131a2a";
    ctx.fillRect(ROAD_PADDING, 0, WIDTH - ROAD_PADDING * 2, HEIGHT);

    // lane markers
    ctx.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue("--lane-line") || "#c8ccd6";
    ctx.lineWidth = 4;
    ctx.setLineDash([16, 16]);
    for (let i = 1; i < LANE_COUNT; i++) {
      const x = ROAD_PADDING + i * LANE_WIDTH;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, HEIGHT);
      ctx.stroke();
    }
    ctx.setLineDash([]);
  }

  function drawCar(x, y, color) {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, PLAYER_WIDTH, PLAYER_HEIGHT);

    // simple windshield
    ctx.fillStyle = "rgba(255,255,255,0.15)";
    ctx.fillRect(x + 6, y + 8, PLAYER_WIDTH - 12, 16);
    // simple shadow
    ctx.fillStyle = "rgba(0,0,0,0.25)";
    ctx.fillRect(x + 4, y + PLAYER_HEIGHT - 10, PLAYER_WIDTH - 8, 6);
  }

  function draw() {
    drawRoad();
    // player
    drawCar(player.x, player.y, getComputedStyle(document.documentElement).getPropertyValue("--car") || "#2ad1ff");
    // enemies
    const enemyColor = getComputedStyle(document.documentElement).getPropertyValue("--enemy") || "#ff5c5c";
    for (let i = 0; i < enemies.length; i++) {
      const e = enemies[i];
      drawCar(e.x, e.y, enemyColor);
    }
  }

  function endGame() {
    gameState = STATE.GameOver;
    overlay.classList.add("visible");
    overlay.querySelector(".panel h1").textContent = "Game Over";
    overlay.querySelector(".sub").textContent = `Score: ${score}`;
    const controls = overlay.querySelector(".controls");
    controls.innerHTML = "";
    const restart = document.createElement("button");
    restart.textContent = "Restart";
    restart.onclick = () => {
      resetGame();
      gameState = STATE.Running;
      overlay.classList.remove("visible");
    };
    controls.appendChild(restart);

    if (score > best) {
      best = score;
      localStorage.setItem("car_game_best", String(best));
      bestEl.textContent = String(best);
    }
  }

  function startGame() {
    resetGame();
    gameState = STATE.Running;
    overlay.classList.remove("visible");
  }

  function togglePause() {
    if (gameState === STATE.Running) {
      gameState = STATE.Paused;
      overlay.classList.add("visible");
      overlay.querySelector(".panel h1").textContent = "Paused";
      overlay.querySelector(".sub").textContent = "Take a breather";
      const controls = overlay.querySelector(".controls");
      controls.innerHTML = "";
      const resume = document.createElement("button");
      resume.textContent = "Resume";
      resume.onclick = () => togglePause();
      controls.appendChild(resume);
    } else if (gameState === STATE.Paused) {
      gameState = STATE.Running;
      overlay.classList.remove("visible");
    }
  }

  // Input
  window.addEventListener("keydown", (e) => {
    if (e.key === "ArrowLeft" || e.key.toLowerCase() === "a") input.left = true;
    if (e.key === "ArrowRight" || e.key.toLowerCase() === "d") input.right = true;
    if (e.key.toLowerCase() === "p") togglePause();
    if (e.key === "Enter" && gameState !== STATE.Running) startGame();
  });
  window.addEventListener("keyup", (e) => {
    if (e.key === "ArrowLeft" || e.key.toLowerCase() === "a") input.left = false;
    if (e.key === "ArrowRight" || e.key.toLowerCase() === "d") input.right = false;
  });

  startBtn.addEventListener("click", startGame);
  pauseBtn.addEventListener("click", togglePause);

  function handleSteering(dt) {
    const laneDelta = (input.right ? 1 : 0) - (input.left ? 1 : 0);
    if (laneDelta !== 0) {
      const newLane = Math.max(0, Math.min(LANE_COUNT - 1, player.targetLane + laneDelta));
      player.targetLane = newLane;
    }
  }

  let lastTime = performance.now();
  function loop(now) {
    const dtMs = Math.min(48, now - lastTime);
    const dt = dtMs / 1000;
    lastTime = now;

    if (gameState === STATE.Running) {
      handleSteering(dt);
      updatePlayer(dt);
      updateEnemies(dt);
      checkCollisions();
      updateSpawn(dtMs);
    }

    draw();
    requestAnimationFrame(loop);
  }

  requestAnimationFrame(loop);
})();
